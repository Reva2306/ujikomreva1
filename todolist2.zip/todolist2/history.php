<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Include koneksi database
include 'database.php';

// Ambil tugas yang sudah selesai
$q_done_tasks = "SELECT * FROM task_history ORDER BY historyid DESC";
$run_q_done_tasks = mysqli_query($conn, $q_done_tasks);

// Logout logic
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>History Tugas</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: url('pemandangan.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .container {
            width: 600px;
            margin: 0 auto;
            padding-top: 30px;
        }
        .header {
            text-align: center;
            padding: 15px;
            background: transparent;
            backdrop-filter: blur(20px);
            border-radius: 10px;
            color: #ff69b4;
            font-weight: bold;
        }
        .card {
            background: transparent;
            backdrop-filter: blur(20px);
            margin-top: 15px;
            padding: 15px;
            border-radius: 10px;
            border-left: 5px solid #ff69b4;
            color: #fff;
        }
        .task-item {
            display: flex;
            justify-content: space-between;
        }
        .task-item span {
            text-decoration: line-through;
            color: #f8a7c7;
        }
        a {
            text-decoration: none;
            color: #ff69b4;
            font-weight: bold;
        }
        a:hover {
            color: #ff3385;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h2>Riwayat Tugas Selesai</h2>
        <p><?= date("l, d M Y") ?></p>
        <a href="index.php">← Kembali ke daftar tugas</a> |
        <a href="?logout=true">Logout</a>
    </div>

    <?php if (mysqli_num_rows($run_q_done_tasks) > 0) {
        while($task = mysqli_fetch_array($run_q_done_tasks)) { ?>
            <div class="card">
                <div class="task-item">
                    <div>
                        <span><?= $task['tasklabel'] ?> (<?= ucfirst($task['prioritas']) ?>)</span>
                        <div style="font-size: 12px; color: #fff;">Tanggal: <?= date('d M Y', strtotime($task['taskdate'])) ?></div>
                    </div>
                </div>
            </div>
    <?php }
    } else { ?>
        <div class="card">Belum ada tugas yang diselesaikan.</div>
    <?php } ?>
</div>

</body>
</html>
