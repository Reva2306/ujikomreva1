<?php
    include 'database.php';

    // Proses update subtask
    if(isset($_POST['update_subtask'])){
        $subtask_id = $_POST['subtask_id'];
        $new_label = $_POST['subtask_label'];

        // Update subtask
        $q_update_subtask = "UPDATE subtasks SET subtasklabel = '".$new_label."' WHERE subtaskid = '".$subtask_id."'";
        $run_q_update_subtask = mysqli_query($conn, $q_update_subtask);

        if($run_q_update_subtask){
            header('Location: index.php');
        }
    }

    // Ambil data subtask yang akan diedit
    if(isset($_GET['id'])){
        $subtask_id = $_GET['id'];
        $q_select_subtask = "SELECT * FROM subtasks WHERE subtaskid = '".$subtask_id."'";
        $run_q_select_subtask = mysqli_query($conn, $q_select_subtask);
        $subtask = mysqli_fetch_array($run_q_select_subtask);
    }
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Subtask</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #ee9ca7;
            background: linear-gradient(to right, #ffdde1, #ee9ca7);
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .input-control {
            width: 100%;
            padding: 0.5rem;
            font-size: 1rem;
            margin-bottom: 10px;
        }
        button {
            width: 100%;
            padding: 0.5rem;
            font-size: 1rem;
            cursor: pointer;
            background: linear-gradient(to right, #ffdde1, #ee9ca7);
            color: #fff;
            border: none;
            border-radius: 3px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Subtask</h2>

    <form action="" method="POST">
        <input type="hidden" name="subtask_id" value="<?= $subtask['subtaskid'] ?>">
        <input type="text" name="subtask_label" class="input-control" value="<?= $subtask['subtasklabel'] ?>" placeholder="Edit subtask">
        <button type="submit" name="update_subtask">edit YOowww!</button>
    </form>
</div>

</body>
</html>